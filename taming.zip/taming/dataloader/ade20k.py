# ------------------------------------------------------------------------------------
# Enhancing Transformers
# Copyright (c) 2022 Thuan H. Nguyen. All Rights Reserved.
# Licensed under the Apache License, Version 2.0 [see LICENSE for details]
# ------------------------------------------------------------------------------------

import PIL
from typing import Any, Tuple, Union, Optional, Callable

import torch
from torchvision import transforms as T
from torchvision.datasets import ImageNet
from torch.utils.data import Dataset
from torchvision.datasets.folder import ImageFolder
import os
import numpy as np
import random

def read_images(path):
    f = open(path)
    lines = f.readlines()
    img_id2path = {}
    for line in lines:
        id, img_path = line.strip('\n').split(' ')
        img_id2path[id] = img_path
    f.close()
    return img_id2path

class ADE20KTrain(Dataset):
    def __init__(self, root='/workplace/dataset/cub', resolution: Union[Tuple[int, int], int] = 256, resize_ratio: float = 0.75):
        images_path = os.path.join(root, 'training')
        self.data = []
        self.segment = []
        self.n_labels = 151
        for catgory_name in os.listdir(images_path):
            for class_name in os.listdir(os.path.join(images_path, catgory_name)):
                for img_name in os.listdir(os.path.join(images_path, catgory_name, class_name)):
                    if '.jpg' not in img_name:
                        continue
                    else:
                        self.data.append(os.path.join(images_path, catgory_name, class_name, img_name))
                        self.segment.append(os.path.join(images_path, catgory_name, class_name, img_name[:-4]+'_seg.png'))

        self.transform = T.Compose([
            T.Resize(resolution),
            # T.RandomCrop(resolution),
            # T.RandomHorizontalFlip(),
            lambda x: np.asarray(x),
        ])
            
    def __getitem__(self, index):
        img, seg = self.data[index], self.segment[index]
        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        img = PIL.Image.open(img).convert('RGB')
        if self.transform is not None:
            img = self.transform(img)
        img = (img/127.5 - 1.0).astype(np.float32)
        
        seg = PIL.Image.open(seg)
        if self.transform is not None:
            seg = self.transform(seg)
        seg = seg.astype(np.uint8)[:,:,0]
        seg = np.eye(self.n_labels)[seg]

        return {'image': img, 'segmentation': seg}

    def __len__(self):
        return len(self.data)

class ADE20KValidation(Dataset):
    def __init__(self, root='/workplace/dataset/cub', resolution: Union[Tuple[int, int], int] = 256, resize_ratio: float = 0.75):
        images_path = os.path.join(root, 'validation')
        self.data = []
        self.segment = []
        self.n_labels = 151
        for catgory_name in os.listdir(images_path):
            for class_name in os.listdir(os.path.join(images_path, catgory_name)):
                for img_name in os.listdir(os.path.join(images_path, catgory_name, class_name)):
                    if '.jpg' not in img_name:
                        continue
                    else:
                        self.data.append(os.path.join(images_path, catgory_name, class_name, img_name))
                        self.segment.append(os.path.join(images_path, catgory_name, class_name, img_name[:-4]+'_seg.png'))

        self.transform = T.Compose([
            T.Resize(resolution),
            # T.RandomCrop(resolution),
            # T.RandomHorizontalFlip(),
            lambda x: np.asarray(x),
        ])
            
    def __getitem__(self, index):
        img, seg = self.data[index], self.segment[index]
        # doing this so that it is consistent with all other datasets
        # to return a PIL Image
        img = PIL.Image.open(img).convert('RGB')
        if self.transform is not None:
            img = self.transform(img)
        img = (img/127.5 - 1.0).astype(np.float32)
        
        seg = PIL.Image.open(seg)
        if self.transform is not None:
            seg = self.transform(seg)
        seg = seg.astype(np.uint8)[:,:,0]
        seg = np.eye(self.n_labels)[seg]

        return {'image': img, 'segmentation': seg}

    def __len__(self):
        return len(self.data)
    
if __name__ == '__main__':
    dataset = ADE20KTrain(root='/home/ices/zhangbq/dataset/ADE20K_2021_17_01/images/ADE/', resolution=(256, 256))
    a  = dataset.__getitem__(1)
    pass

