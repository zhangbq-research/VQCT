import hashlib
import os
import urllib
import warnings
from typing import Any, Union, List
from pkg_resources import packaging

import torch
from PIL import Image
from torchvision.transforms import Compose, Resize, CenterCrop, ToTensor, Normalize
from tqdm import tqdm

from .model import build_model
from .simple_tokenizer import SimpleTokenizer as _Tokenizer

class tokenize():
    def __init__(self):
        self.tokenizer = _Tokenizer()

    # def load(name: str, device: Union[str, torch.device] = "cuda" if torch.cuda.is_available() else "cpu",
    #         jit: bool = False, download_root: str = None):
    #     """Load a CLIP model

    #     Parameters
    #     ----------
    #     name : str
    #         A model name listed by `clip.available_models()`, or the path to a model checkpoint containing the state_dict

    #     device : Union[str, torch.device]
    #         The device to put the loaded model

    #     jit : bool
    #         Whether to load the optimized JIT model or more hackable non-JIT model (default).

    #     download_root: str
    #         path to download the model files; by default, it uses "~/.cache/clip"

    #     Returns
    #     -------
    #     model : torch.nn.Module
    #         The CLIP model

    #     preprocess : Callable[[PIL.Image], torch.Tensor]
    #         A torchvision transform that converts a PIL image into a tensor that the returned model can take as its input
    #     """
    #     model_path = name
    #     with open(model_path, 'rb') as opened_file:
    #         try:
    #             # loading JIT archive
    #             model = torch.jit.load(opened_file, map_location=device if jit else "cpu").eval()
    #             state_dict = None
    #         except RuntimeError:
    #             # loading saved state dict
    #             if jit:
    #                 warnings.warn(f"File {model_path} is not a JIT archive. Loading as a state dict instead")
    #                 jit = False
    #             state_dict = torch.load(opened_file, map_location="cpu")

    #     if not jit:
    #         model = build_model(state_dict or model.state_dict()).to(device)
    #         if str(device) == "cpu":
    #             model.float()
    #         return model

    #     # patch the device names
    #     device_holder = torch.jit.trace(lambda: torch.ones([]).to(torch.device(device)), example_inputs=[])
    #     device_node = [n for n in device_holder.graph.findAllNodes("prim::Constant") if "Device" in repr(n)][-1]

    #     def _node_get(node: torch._C.Node, key: str):
    #         """Gets attributes of a node which is polymorphic over return type.
            
    #         From https://github.com/pytorch/pytorch/pull/82628
    #         """
    #         sel = node.kindOf(key)
    #         return getattr(node, sel)(key)

    #     def patch_device(module):
    #         try:
    #             graphs = [module.graph] if hasattr(module, "graph") else []
    #         except RuntimeError:
    #             graphs = []

    #         if hasattr(module, "forward1"):
    #             graphs.append(module.forward1.graph)

    #         for graph in graphs:
    #             for node in graph.findAllNodes("prim::Constant"):
    #                 if "value" in node.attributeNames() and str(_node_get(node, "value")).startswith("cuda"):
    #                     node.copyAttributes(device_node)

    #     model.apply(patch_device)
    #     patch_device(model.encode_image)
    #     patch_device(model.encode_text)

    #     # patch dtype to float32 on CPU
    #     if str(device) == "cpu":
    #         float_holder = torch.jit.trace(lambda: torch.ones([]).float(), example_inputs=[])
    #         float_input = list(float_holder.graph.findNode("aten::to").inputs())[1]
    #         float_node = float_input.node()

    #         def patch_float(module):
    #             try:
    #                 graphs = [module.graph] if hasattr(module, "graph") else []
    #             except RuntimeError:
    #                 graphs = []

    #             if hasattr(module, "forward1"):
    #                 graphs.append(module.forward1.graph)

    #             for graph in graphs:
    #                 for node in graph.findAllNodes("aten::to"):
    #                     inputs = list(node.inputs())
    #                     for i in [1, 2]:  # dtype can be the second or third argument to aten::to()
    #                         if _node_get(inputs[i].node(), "value") == 5:
    #                             inputs[i].node().copyAttributes(float_node)

    #         model.apply(patch_float)
    #         patch_float(model.encode_image)
    #         patch_float(model.encode_text)

    #         model.float()

    #     return model


    def tokenize(self,texts: Union[str, List[str]], context_length: int = 77, truncate: bool = False) -> Union[
        torch.IntTensor, torch.LongTensor]:
        """
        Returns the tokenized representation of given input string(s)

        Parameters
        ----------
        texts : Union[str, List[str]]
            An input string or a list of input strings to tokenize

        context_length : int
            The context length to use; all CLIP models use 77 as the context length

        truncate: bool
            Whether to truncate the text in case its encoding is longer than the context length

        Returns
        -------
        A two-dimensional tensor containing the resulting tokens, shape = [number of input strings, context_length].
        We return LongTensor when torch version is <1.8.0, since older index_select requires indices to be long.
        """
        if isinstance(texts, str):
            texts = [texts]
        
        sot_token = self.tokenizer.encoder["<|startoftext|>"]
        eot_token = self.tokenizer.encoder["<|endoftext|>"]
        all_tokens = [[sot_token] + self.tokenizer.encode(text) + [eot_token] for text in texts]
        if packaging.version.parse(torch.__version__) < packaging.version.parse("1.8.0"):
            result = torch.zeros(len(all_tokens), context_length, dtype=torch.long)
        else:
            result = torch.zeros(len(all_tokens), context_length, dtype=torch.int)

        for i, tokens in enumerate(all_tokens):
            if len(tokens) > context_length:
                if truncate:
                    tokens = tokens[:context_length]
                    tokens[-1] = eot_token
                else:
                    raise RuntimeError(f"Input {texts[i]} is too long for context length {context_length}")
            result[i, :len(tokens)] = torch.tensor(tokens)

        return result
